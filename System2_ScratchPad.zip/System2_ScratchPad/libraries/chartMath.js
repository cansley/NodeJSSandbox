/**
 * Created by cxa70 on 1/9/2015.
 */
var ChartMath = function(){

}


Array.prototype.Max = function(){
    return Math.max.apply(Math, this);
};

Array.prototype.Min = function(){
    return Math.min.apply(Math, this);
};


ChartMath.prototype.StandardDeviation = function(values){
    var avg = this.Average(values);

    var squareDiffs = values.map(function(value){
        var diff = value - avg;
        var sqrDiff = diff * diff;
        return sqrDiff;
    });

    var avgSquareDiff = this.Average(squareDiffs);

    var stdDev = Math.sqrt(avgSquareDiff);
    return stdDev;
}

ChartMath.prototype.Average = function(data){
    var sum = data.reduce(function(sum, value){
        return sum + value;
    }, 0);

    var avg = sum / data.length;
    return avg;
}

module.exports  = ChartMath;