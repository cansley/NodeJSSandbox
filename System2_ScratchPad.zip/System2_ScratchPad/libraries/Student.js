/**
 * Created by cxa70 on 1/9/2015.
 */

var Student = function(name, grade, score1, score2, Grades){
    require('./Scoring.js');

    this.Name =name;
    this.Grade=grade;
    this.Score1 = score1;
    this.Score2 = score2;
    this.Growth = this.Score2 - this.Score1;
    this.PercentGrowth = this.Growth / this.Score2;
    this.Attain = Grades[this.Grade][this.Score2][0]; // lookup
    this.CalcGrowth = Grades[this.Grade][this.Growth][1]; // lookup
    this.Designation = this.Attain + this.CalcGrowth;
};

module.exports =Student;