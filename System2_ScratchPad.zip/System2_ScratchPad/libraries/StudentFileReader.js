/**
 * Created by cxa70 on 1/9/2015.
 */
var Student = require('./Student.js');
var gradeRef = require('./Scoring.js');
var fs = require('fs');
var readline = require('readline');
var stream = require('stream');

module.exports.CreateStudentsFromFile = function(filePath, callback){
    var readStream = fs.createReadStream(filePath);
    var outStream = new stream;

    var rl = readline.createInterface({
        input: readStream,
        output: outStream,
        terminal: false
    });

    var csv = require('csv');
    var Students = [];
    rl.on('line', function(line){
        csv.parse(line, function(err, data){
            data.forEach(function(arr){
                Students[Students.length] = new Student(arr[0], Number(arr[1]), Number(arr[2]), Number(arr[3]), gradeRef.Grades);
            });
        });
    });

    rl.on('close', function(){
        callback(Students);
    });
};

